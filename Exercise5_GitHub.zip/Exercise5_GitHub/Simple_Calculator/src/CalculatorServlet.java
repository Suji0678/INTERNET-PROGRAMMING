import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        double num1;
        double num2;
        int operation;
        try {
            num1 = Double.parseDouble(request.getParameter("num1"));
            num2 = Double.parseDouble(request.getParameter("num2"));
            operation = Integer.parseInt(request.getParameter("operation"));
        } catch (NumberFormatException | NullPointerException ex) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Please enter valid numbers and select an operation.");
            return;
        }

        double result;
        String operationName;
        switch (operation) {
            case 1: result = num1 + num2; operationName = "Addition"; break;
            case 2: result = num1 - num2; operationName = "Subtraction"; break;
            case 3: result = num1 * num2; operationName = "Multiplication"; break;
            case 4:
                if (num2 == 0) {
                    response.getWriter().println("<!DOCTYPE html><html><body><h2>Cannot divide by zero!</h2></body></html>");
                    return;
                }
                result = num1 / num2; operationName = "Division"; break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid operation.");
                return;
        }

        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Calculator Result</title></head><body>");
        out.println("<h2>Calculator Result</h2>");
        out.println("<p>First Number: " + num1 + "</p>");
        out.println("<p>Second Number: " + num2 + "</p>");
        out.println("<p>Operation: " + operationName + "</p>");
        out.println("<h3>Result: " + result + "</h3>");
        out.println("</body></html>");
    }
}
