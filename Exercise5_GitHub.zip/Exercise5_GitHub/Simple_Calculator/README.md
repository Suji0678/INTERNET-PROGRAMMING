# Simple Calculator

Files for the calculator program in Exercise 5:
- `index.html` – calculator form (uses `CalculatorServlet` as its POST action)
- `CalculatorServlet.java` – servlet logic for arithmetic operations

Refer to `EXERCISE_5_Original.docx` in the repository root for the full original code.
