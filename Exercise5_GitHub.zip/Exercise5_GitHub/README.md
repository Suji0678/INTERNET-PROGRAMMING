# Exercise 5 – Java Servlet Programs

This repository contains the two programs from Exercise 5.

## Folder structure

- `Quiz_Application/` – Quiz form and `ExamServlet.java`
- `Simple_Calculator/` – Calculator form and `CalculatorServlet.java`

## Requirements

- JDK
- Apache Tomcat
- A Java IDE such as Eclipse or NetBeans

## Notes

The original document contains the program code and output headings. The HTML forms use servlet URL mappings:
- `/ExamServlet`
- `/CalculatorServlet`

Place the HTML files in the web application's web root and the Java servlet files in the source package folder of your servlet project. Ensure the servlet API version/imports match your Tomcat version.
