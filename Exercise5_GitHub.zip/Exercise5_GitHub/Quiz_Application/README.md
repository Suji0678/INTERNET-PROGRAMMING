# Quiz Application

Files for the quiz program in Exercise 5:
- `index.html` – quiz form (uses `ExamServlet` as its POST action)
- `ExamServlet.java` – servlet logic for checking answers and displaying score

Refer to `EXERCISE_5_Original.docx` in the repository root for the full original code.
