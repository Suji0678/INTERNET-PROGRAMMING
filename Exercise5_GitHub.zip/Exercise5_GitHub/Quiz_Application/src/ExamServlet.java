import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ExamServlet")
public class ExamServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String q1 = request.getParameter("q1");
        String q2 = request.getParameter("q2");
        String q3 = request.getParameter("q3");
        String q4 = request.getParameter("q4");
        String q5 = request.getParameter("q5");
        int score = 0;
        if ("Paris".equals(q1)) score++;
        if ("4".equals(q2)) score++;
        if ("Peacock".equals(q3)) score++;
        if ("*".equals(q4)) score++;
        if ("style".equals(q5)) score++;

        PrintWriter out = response.getWriter();
        out.println("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Quiz Result</title></head><body>");
        out.println("<h1>Quiz Result</h1>");
        out.println("<h2>Welcome " + escapeHtml(username) + "</h2>");
        out.println("<p>Your Score: <b>" + score + " / 5</b></p>");
        if (score == 5) out.println("<h3>Excellent!</h3>");
        else if (score >= 3) out.println("<h3>Good Job!</h3>");
        else out.println("<h3>Try Again!</h3>");
        out.println("</body></html>");
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
                    .replace(">", "&gt;").replace(""", "&quot;")
                    .replace("'", "&#x27;");
    }
}
